# Create a package
root# echo "name=hello" > /tmp/pkg/manifest.txt
root# echo "version=1.0" >> /tmp/pkg/manifest.txt
root# echo "description=Hello world app" >> /tmp/pkg/manifest.txt
root# echo "type=app" >> /tmp/pkg/manifest.txt
root# mkdir /tmp/pkg/bin
root# cp hello.cs /tmp/pkg/bin/hello.cs
root# zip /tmp/hello.npak /tmp/pkg

# Install
root# npak install /tmp/hello.npak
Installing hello 1.0...
  /usr/local/bin/hello.cs
  1 file(s) installed
npak: hello 1.0 installed successfully

# List & info
root# npak list
  hello 1.0 — Hello world app

root# npak info hello
Name:        hello
Version:     1.0
Type:        app
Description: Hello world app
Files:       1
  /usr/local/bin/hello.cs

# Remove
root# npak remove hello
Removing hello...
  removed /usr/local/bin/hello.cs
npak: hello removed (1 file(s))