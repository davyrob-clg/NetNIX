#!/bin/nsh
echo "Testing zip and wget functions...(NETWORK REQUIRED)"
echo "Download basic-text.zip from sample-files.com"
echo ""
wget https://sample-files.com/downloads/compressed/zip/basic-text.zip
echo ""
echo "OK. File downloaded"
echo "Extracting..."
unzip basic-text.zip basic-text
echo "OK. Extracted, let's look inside..."
echo ""
ls basic-text
echo ""
echo "Looks good, let's make a backup zip out of it..."
zip basictextbackup.zip basic-text/
echo ""
echo "There we go, but does the BACKUP work?..."
unzip basictextbackup.zip tested-backup
echo ""
echo "Did it work?..."
ls tested-backup/basic-text
echo "Great. All works fine"







